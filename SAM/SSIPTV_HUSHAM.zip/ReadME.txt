This is a Husham.com SSIPTV Solution for Samsung TVs
Please see husham.com for full infomration