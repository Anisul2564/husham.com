Updated March 2020 with latest files
====================================
Place the both Directories of SMARTIPTV and userwidget on the Root of your USB STICK
Please check updates on the https://forum.husham.com/ for all updates on husham.com
Forum link - https://forum.husham.com/forums/smart-iptv.41/

Thank you for Downloading from Husham.com - 
Subscribe to Husham Channel https://www.husham.com/youtubechannel Youtube channel please
http://www.Cocoscope.com/hushammemar
Husham Memar

Full infomration located on this page 
https://www.husham.com/warning-samsung-removes-smart-iptv-do-not-rest-your-tv/

P.S. Important! The application does NOT work on D series or older Samsung TVs. Find out what Samsung TV you have go to this page https://www.husham.com/what-samsung-tv-model-i-have/
Best Regards People,  I shall keep you updated on any changes to this situation.
Husham Memar