import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmdhbWVtYXN0ZXJz')

name = b.b64decode('R2FtZSBNYXN0ZXJz')

host = b.b64decode('aHR0cDovL21haW5zLnNlcnZpY2Vz')

port = b.b64decode('MjA4Ng==')