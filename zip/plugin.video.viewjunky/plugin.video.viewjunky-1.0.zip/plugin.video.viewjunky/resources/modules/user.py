import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnZpZXdqdW5reQ==')

name = b.b64decode('VmlldyBKdW5reQ==')

host = b.b64decode('aHR0cDovL25ldy52aWV3anVua3kuY29t')

port = b.b64decode('ODM=')