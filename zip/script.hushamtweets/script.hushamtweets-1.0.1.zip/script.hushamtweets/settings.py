
import xbmcaddon

# Plugin Info
REAL_SETTINGS = xbmcaddon.Addon()
REAL_SETTINGS.openSettings() 