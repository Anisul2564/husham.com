import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJlZHplYnJh')

name = b.b64decode('UmVkemVicmE=')

host = b.b64decode('aHR0cDovLzEwNC4yNDMuMzIuNjg=')

port = b.b64decode('MjU0NjE=')